# Changelog

## 0.3.0
- Pre-listed server shops: catalog.yml ships with 6 shops and 168 items (Building Blocks, Farming and Food, Ores and Materials, Tools and Armor, Redstone and Utility, Mob Drops and Rare), priced in copper, iron, gold, emerald and diamond.
- Catalog is loaded on start and on /shopadmin reload. Edit the file to change items and prices. Catalog shops are read-only in menus.

## 0.2.0
- The main shop is now a central GUI market opened with /shop. No chest or block needed.
- Market: category tabs, sort by newest or name, pagination, escrow stock, add stock, cancel listing, optional expiry.
- Chest shops are now an optional extra (config chest-shops.enabled), created with /shop chest create.
- Server shops (admin, infinite stock) kept. Collect box, transaction log and container protection kept.
- Source is not compiled yet. First step for the next session: run the GitHub Actions build and fix compile errors.

## 0.1.0
- First draft with chest shops as the main feature. Superseded by 0.2.0.
