# MaterialShop handoff (version 0.2.0)

## State
Complete source for the GUI market design: Market, My listings, Server shops, optional chest shops, collect box, escrow, expiry, transaction log.
NOT compiled against the Paper API. Only a syntax check was done. Expect a few compile errors.

## Next steps, in order
1. Copy the Java version and Paper API version from the MaterialClaim pom into pom.xml (properties java.version, paper.version), plugin.yml api-version and the workflow java-version.
2. Push to a new public repo named MaterialShop. Run the Build workflow. Fix every compile error without changing behaviour.
3. Re-read Trade.java, Gui.java (SetupMenu, ListingManageMenu) and ShopManager.java (market storage, expire) for item loss or duplication bugs.
4. Test on the server with the README checklist.
5. Later ideas: price editing, MaterialClaim and WorldGuard hooks, search by item name.

## Files
- Trade.java: trade engine for market and shop listings.
- Gui.java: all menus (MainMenu, MarketMenu, MyListingsMenu, ListingManageMenu, SetupMenu, PurchaseMenu, ShopMenu, ManageMenu, ListMenu, CollectMenu).
- ShopManager.java: storage for shops.yml, market.yml, collect.yml.
- Category.java: market tab mapping.
- ProtectionListener.java, GuiListener.java, ShopCommand.java, MaterialShop.java, Text.java, Listing.java, Shop.java.

## Continuation prompt
You are continuing the Minecraft Paper plugin MaterialShop (GUI barter market, no money). The source is complete but never compiled. Do this: (1) copy Java and Paper API versions from the MaterialClaim repo into pom.xml, plugin.yml and the workflow; (2) run the GitHub Actions build and fix all compile errors without changing behaviour; (3) review Trade.java, Gui.java and ShopManager.java for item loss or duplication; (4) update CHANGELOG.md and HANDOFF.md; (5) report build status, jar location and anything untested. If your limit is close, commit what you have, update HANDOFF.md and give a new continuation prompt plus all files.
